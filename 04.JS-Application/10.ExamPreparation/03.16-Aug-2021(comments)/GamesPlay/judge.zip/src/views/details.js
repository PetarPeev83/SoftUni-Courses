import { createComment, deleteGame, getCommentsByBookId, getGameById } from "../api/data.js";
import { html } from "../lib.js";
import { getUserData } from "../util.js";

const detailsTemplate = (game, isOwner, onDelete, comments, isGuest,onComment) => html`
<section id="game-details">
    <h1>Game Details</h1>
    <div class="info-section">

        <div class="game-header">
            <img class="game-img" src=${game.imageUrl} />
            <h1>${game.title}</h1>
            <span class="levels">MaxLevel: ${game.maxLevel}</span>
            <p class="type">${game.category}</p>
        </div>

        <p class="text">${game.summary}</p>

        <!-- Bonus ( for Guests and Users ) -->
        <div class="details-comments">
            <h2>Comments:</h2>
            <ul>
                <!-- list all comments for current game (If any) -->
                ${comments.length == 0 
                ? html`<p class="no-comment">No comments.</p>`
                : html`${comments.map(commentCard)}`
            }
            </ul>
            
        </div>

        ${isOwner ? html`
        <div class="buttons">
            <a class="button" href="/edit/${game._id}">Edit</a>
            <a class="button" @click=${onDelete} href="javascript:void(0)">Delete</a>
        </div>`
     : null}

    </div>

    <!-- Bonus -->
    <!-- Add Comment ( Only for logged-in users, which is not creators of the current game ) -->

    ${isOwner || isGuest   ? null
    :html`<article class="create-comment">
        <label>Add new comment:
        </label>
        <form @submit=${onComment} class="form">
            <textarea name="comment" placeholder="Comment......"></textarea>
            <input class="btn submit" type="submit" value="Add Comment">
        </form>
    </article>`}

</section>`;

const commentCard = (comment) => html`
    <li class="comment">
        <p>Content: ${comment.comment}</p>
    </li>`;

// const detailsTemplate = (book, isOwner, onDelete, likes, hasLike, isGuest,onLike) => html`
// <section id="details-page" class="details">
//     <div class="book-information">
//         <h3>${book.title}</h3>
//         <p class="type">Type: ${book.type}</p>
//         <p class="img"><img src=${book.imageUrl}></p>
//         <div class="actions">
//             <!-- Edit/Delete buttons ( Only for creator of this book )  -->

//             ${isOwner ? html`
//             <a class="button" href="/edit/${book._id}">Edit</a>
//             <a class="button" @click=${onDelete} href="javascript:void(0)">Delete</a>`
//             : null}

//             <!-- Bonus -->
//             <!-- Like button ( Only for logged-in users, which is not creators of the current book ) -->

//             ${isOwner || isGuest || hasLike ? null 
//                 : html`<a class="button" @click=${onLike} href="javascript:void(0)">Like</a>`}

//             <!-- ( for Guests and Users )  -->
//             <div class="likes">
//                 <img class="hearts" src="/images/heart.png">
//                 <span id="total-likes">Likes: ${likes}</span>
//             </div>
//             <!-- Bonus -->
//         </div>
//     </div>
//     <div class="book-description">
//         <h3>Description:</h3>
//         <p>${book.description}</p>
//     </div>
// </section>`;

export async function detailsPage(ctx) {

    // const game = await getGameById(ctx.params.id);      // вкарвам го в promise.all за да го пусна със заявките за коментарите!!!;
    const userData = getUserData();

    const [game, comments] = await Promise.all([
        getGameById(ctx.params.id),
        getCommentsByBookId(ctx.params.id),
    ]);

    

    const isOwner = userData && userData.id == game._ownerId;
    const isGuest = userData == null;

    ctx.render(detailsTemplate(game, isOwner, onDelete, comments, isGuest,onComment));

    async function onDelete() {
        const choice = confirm(`Are You Sure You Want To Delete "${game.title}" ?`);
        if (choice) {
            await deleteGame(ctx.params.id);
            ctx.page.redirect('/');
        };
    };

    async function onComment(event) {
        event.preventDefault();
        const formData = new FormData(event.target);
        const comment = formData.get('comment').trim(); 
        // console.log(event.target);
        event.target[0].value = "";

        await createComment(ctx.params.id , comment);
        ctx.page.redirect(`/details/` + ctx.params.id);
    };
};